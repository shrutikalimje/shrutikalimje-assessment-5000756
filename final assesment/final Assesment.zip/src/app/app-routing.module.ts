import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FlightHomeComponent } from './component/flight-home/flight-home.component';
import { FlightAddComponent } from './component/flight-add/flight-add.component';
import { FlightListComponent } from './component/flight-list/flight-list.component';
const routes: Routes = [
  { path: 'home', component: FlightHomeComponent },
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'BookFlight', component: FlightAddComponent },
  { path: 'viewFlights', component: FlightListComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
