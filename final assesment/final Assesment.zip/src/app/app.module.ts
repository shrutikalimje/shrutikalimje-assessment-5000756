import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FlightHomeComponent } from './component/flight-home/flight-home.component';
import { FlightListComponent } from './component/flight-list/flight-list.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlightAddComponent } from './component/flight-add/flight-add.component';
import { FlightUpdateComponent } from './flight-update/flight-update.component';
import { AmplifyAuthenticatorModule } from '@aws-amplify/ui-angular';
@NgModule({
  declarations: [
    AppComponent,
    FlightHomeComponent,
    FlightListComponent,
    FlightAddComponent,
    FlightUpdateComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AmplifyAuthenticatorModule,
    /* configuring form modules */
    FormsModule,
    ReactiveFormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
