import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-flight-update',
  templateUrl: './flight-update.component.html',
  styleUrls: ['./flight-update.component.css'],
})
export class FlightUpdateComponent {
  @Input() flight!: any;
  @Input() passenger: any;
  @Output() OnUpdateId: EventEmitter<any> = new EventEmitter();

  passengerName: string = '';
  passengerTicket: string = '';
  passengerPrice: string = '';
}
