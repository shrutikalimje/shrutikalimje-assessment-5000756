export type AmplifyDependentResourcesAttributes = {
  "api": {
    "flightbooking": {
      "GraphQLAPIEndpointOutput": "string",
      "GraphQLAPIIdOutput": "string",
      "GraphQLAPIKeyOutput": "string"
    }
  }
}