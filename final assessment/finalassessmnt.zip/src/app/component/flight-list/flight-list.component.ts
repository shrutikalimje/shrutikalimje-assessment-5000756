import { Component, OnInit } from '@angular/core';
import { APIService, Passenger } from 'src/app/API.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-flight-list',
  templateUrl: './flight-list.component.html',
  styleUrls: ['./flight-list.component.css'],
})
export class FlightListComponent implements OnInit {
  passenger!: Passenger[];
  currentPassenger!: Passenger;
  ondelete?: any;
  onupdate?: any;
  constructor(private api: APIService) {}

  ngOnInit() {
    this.api
      .ListPassengers()
      .then((event) => {
        this.passenger = event.items as Passenger[];
        console.log(this.passenger);
      })
      .catch((e) => {
        console.log('error in fetching ', e);
      });
  }

  public onDelete(passenger: Passenger) {
    this.api
      .DeletePassenger({ id: passenger.id })
      .then((event) => {
        console.log(event);
        console.log('item deleted!');
      })
      .catch((e) => {
        console.log('error deleting passenger', e);
      });
  }

  deleteSub = this.api.OnDeletePassengerListener().subscribe((data) => {
    console.log(data);
    this.ondelete = data.value.data?.onDeletePassenger;
    this.passenger = this.passenger.filter((x) => x.id != this.ondelete.id);
  });

  id: string = '';
  setUpdateId(id: string) {
    this.id = id;
  }

  public onUpdate(passenger: any) {
    this.api
      .UpdatePassenger({
        id: this.id,
        name: passenger.name,
        ticket: passenger.Ticket,
        price: passenger.price,
      })
      .then((event) => {
        console.log('item Updated');
        console.log(event);
      })
      .catch((e) => {
        console.log('error in updating..', e);
      });
  }

  updatesub = this.api.OnUpdatePassengerListener().subscribe((data) => {
    console.log(data);
    this.onupdate = data.value.data?.onUpdatePassenger;
    this.passenger = this.passenger.filter((x) => x.id != this.onupdate.id);
    this.passenger = [...this.passenger, this.onupdate];
  });
}
