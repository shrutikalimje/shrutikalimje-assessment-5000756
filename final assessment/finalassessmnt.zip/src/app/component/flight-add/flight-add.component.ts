import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { APIService, Passenger } from 'src/app/API.service';
import { Store } from '@ngrx/store';
import { flightAdd } from 'src/app/store/action/flight.action';
import { __values } from 'tslib';
@Component({
  selector: 'app-flight-add',
  templateUrl: './flight-add.component.html',
  styleUrls: ['./flight-add.component.css'],
})
export class FlightAddComponent implements OnInit {
  public createForm: FormGroup;

  public passengers: Array<Passenger> = [];

  oncreate?: any;

  constructor(private api: APIService, private fb: FormBuilder) {
    this.createForm = this.fb.group({
      Name: ['', Validators.required],
      Ticket: ['', Validators.required],
      Id: ['', Validators.required],
    });
  }

  async ngOnInit() {}

  public onCreate(passengers: Passenger) {
    this.api
      .CreatePassenger(passengers)
      .then((event) => {
        console.log(event);
        this.createForm.reset();
        this.store.dispatch(flightAdd({ passenger: passengers }));
      })
      .catch((e) => {
        console.log('error in Oncreate', e);
      });
  }

  addSub = this.api.OnCreatePassengerListener().subscribe((data) => {
    console.log(data);
    this.oncreate = data.value.data?.onCreatePassenger;
    this.passengers = [...this.passengers, this.oncreate];
  });
}
