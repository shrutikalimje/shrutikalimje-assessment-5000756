import { createFeatureSelector, createSelector, State } from '@ngrx/store';
import { AppState } from '../models/appState';
import { FlightState } from '../reducer/flight.reducer';
import { Flight } from '../models/model';

export const selectFlightList = createFeatureSelector<AppState, FlightState>(
  'flightState'
);

export const selectFlights = createSelector(
  selectFlightList,
  (State: FlightState) => State.flights
);
