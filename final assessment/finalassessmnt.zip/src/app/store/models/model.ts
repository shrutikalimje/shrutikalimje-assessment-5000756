export interface Flight {
  id: string;
  name: string;
  passenger: [Passenger];
}

export interface Passenger {
  name: string;
  price: number;
  ticket: number;
}
