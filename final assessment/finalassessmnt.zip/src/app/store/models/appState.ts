import { FlightState } from '../reducer/flight.reducer';
import { passengerState } from '../reducer/flight.reducer';
export interface AppState {
  flightState: FlightState;
}

export interface AppState2 {
  passengerState: passengerState;
}
