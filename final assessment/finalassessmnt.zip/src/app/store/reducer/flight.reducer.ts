import { state } from '@angular/animations';
import { createReducer, on } from '@ngrx/store';
import { flightAdd, flightUpdate, flightList } from '../action/flight.action';
import { Flight, Passenger } from '../models/model';

export interface FlightState {
  flights: Flight[];
}

export interface passengerState {
  passenger: Passenger[];
}

export const initialstate: FlightState = {
  flights: [],
};

export const initialstate2: passengerState = {
  passenger: [],
};

export const flightReducer = createReducer(
  initialstate,
  on(flightAdd, (state, { flight }) => {
    return{
      ...state,
      flights: [...state.flights, flight]
    }
})),

  on(flightUpdate, (state, { flight }) => {
    var newFlight = [...state.flights]
    newFlight = newFlight.filter((x) => x.id != flight.id);
    return {
      ...state,flights:[...newFlight,flight]
    }
  })
);
