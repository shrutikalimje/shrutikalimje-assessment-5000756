import { createAction, props } from '@ngrx/store';
import { Flight } from 'src/app/API.service';

export const flightAdd = createAction(
  'add flight [flight add]',
  props<{ flight: Flight }>()
);

export const flightUpdate = createAction(
  '[flight-update] FlightUpdate',
  props<{ flight: Flight }>()
);

export const flightList = createAction(
  '[flight-list] Flight-list',
  props<{ flight: Flight[] }>()
);
